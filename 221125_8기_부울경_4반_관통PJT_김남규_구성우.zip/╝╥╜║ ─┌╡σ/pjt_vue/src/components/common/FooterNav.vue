<template>
  <div>
    <div class="footer">
      <div style="vertical-align: middle">&copy; 구성우, 김남규</div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
.footer {
  color: lightblue;
  background-color: rgba(0, 0, 0, 0.8);
  position: fixed;
  width: 100%;
  bottom: 0;
  font-size: 17px;
  min-height: 50px;
  text-align: center;
  line-height: 50px;
}
</style>
