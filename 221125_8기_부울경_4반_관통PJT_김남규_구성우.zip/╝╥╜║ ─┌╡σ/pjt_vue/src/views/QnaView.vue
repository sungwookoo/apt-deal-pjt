<template>
  <div>
    <b-container
      class="mt-4 bg-light bg-opacity-75 pt-4"
      style="max-height: 730px; height: 730px">
      <router-view type="1"></router-view>
    </b-container>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
